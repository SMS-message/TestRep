import os
import sys
import pygame


def load_image(name: str, color_key: None | int = None) -> pygame.surface.Surface:
    fullname = os.path.join('img', name)
    if not os.path.isfile(fullname):
        print(f'Файл с изображением {fullname} не найден.')
        sys.exit(1)
    image = pygame.image.load(fullname)
    if color_key is not None:
        image = image.convert()
        if color_key == -1:
            color_key = image.get_at((1, 1))
        image.set_colorkey(color_key)
    else:
        image = image.convert_alpha()

    return image
