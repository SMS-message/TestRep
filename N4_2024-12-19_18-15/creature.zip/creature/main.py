import pygame
from data.functions import load_image


def main() -> int:
    pygame.init()
    size = width, height = (300, 300)
    screen = pygame.display.set_mode(size)

    image = load_image('creature.png', -1)
    creature_pos = [0, 0]

    screen.fill("#121212")
    clock = pygame.time.Clock()
    running = True

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                if event.key in (pygame.K_UP, pygame.K_w):
                    creature_pos[1] -= 10
                if event.key in (pygame.K_DOWN, pygame.K_s):
                    creature_pos[1] += 10
                if event.key in (pygame.K_RIGHT, pygame.K_d):
                    creature_pos[0] += 10
                if event.key in (pygame.K_LEFT, pygame.K_a):
                    creature_pos[0] -= 10

        screen.fill("#121212")
        screen.blit(image, creature_pos)

        pygame.display.flip()

        clock.tick(60)

    pygame.quit()
    return 0


if __name__ == '__main__':
    main()
