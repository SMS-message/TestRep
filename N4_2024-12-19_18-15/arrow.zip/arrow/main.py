import pygame
from data.functions import load_image


def main() -> int:
    pygame.init()
    size = width, height = (1280, 720)
    screen = pygame.display.set_mode(size)

    image = load_image('arrow.png')
    screen.fill("#121212")
    clock = pygame.time.Clock()
    running = True
    pygame.mouse.set_visible(False)

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        screen.fill("#121212")
        if pygame.mouse.get_focused():
            screen.blit(image, pygame.mouse.get_pos())

        pygame.display.flip()

        clock.tick(60)

    pygame.quit()
    return 0


if __name__ == '__main__':
    main()
